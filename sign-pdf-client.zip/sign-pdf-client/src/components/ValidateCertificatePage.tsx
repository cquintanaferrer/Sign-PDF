export function ValidateCertificatePage() {
  return (
    <div
      className="min-h-screen"
      style={{ backgroundColor: '#f0f5fe' }}
    >
      <div className="max-w-5xl mx-auto px-6 py-12">

        <div className="mb-8">
          <p
            className="mono text-xs font-semibold tracking-widest uppercase mb-2"
            style={{ color: '#10b981' }}
          >
            Validación X.509
          </p>

          <h1
            className="text-3xl font-semibold"
            style={{ color: '#0a1628' }}
          >
            Validar certificado
          </h1>

          <p
            className="mt-2 text-sm"
            style={{ color: '#3b6fd4' }}
          >
            Comprueba la validez de un certificado digital.
          </p>
        </div>

        <div
          className="bg-white rounded-2xl p-10"
          style={{ border: '1px solid #dce8fd' }}
        >
          <label
            className="block text-sm font-medium mb-2"
            style={{ color: '#0a1628' }}
          >
            Certificado
          </label>

          <input
            type="file"
            accept=".pem,.crt,.cer"
            className="block w-full text-sm"
          />

          <button
            className="mt-6 px-5 py-2.5 rounded-lg text-sm font-medium text-white"
            style={{ backgroundColor: '#2450a4' }}
            onClick={() => {}}
          >
            Validar certificado
          </button>
        </div>

      </div>
    </div>
  )
}