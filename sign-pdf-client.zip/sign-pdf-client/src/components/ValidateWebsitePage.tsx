export function ValidateWebsitePage() {
  return (
    <div
      className="min-h-screen"
      style={{ backgroundColor: '#f0f5fe' }}
    >
      <div className="max-w-5xl mx-auto px-6 py-12">

        <div className="mb-8">
          <p
            className="mono text-xs font-semibold tracking-widest uppercase mb-2"
            style={{ color: '#10b981' }}
          >
            TLS / X.509
          </p>

          <h1
            className="text-3xl font-semibold"
            style={{ color: '#0a1628' }}
          >
            Validar certificado de sitio
          </h1>

          <p
            className="mt-2 text-sm"
            style={{ color: '#3b6fd4' }}
          >
            Comprueba el certificado TLS presentado por un
            sitio web externo.
          </p>
        </div>

        <div
          className="bg-white rounded-2xl p-10"
          style={{ border: '1px solid #dce8fd' }}
        >
          <label
            className="block text-sm font-medium mb-2"
            style={{ color: '#0a1628' }}
          >
            URL del sitio
          </label>

          <input
            type="url"
            placeholder="https://example.com"
            className="w-full px-4 py-3 rounded-lg text-sm outline-none"
            style={{
              border: '1px solid #c7d8f5',
              color: '#0a1628',
            }}
          />

          <button
            className="mt-6 px-5 py-2.5 rounded-lg text-sm font-medium text-white"
            style={{ backgroundColor: '#2450a4' }}
            onClick={() => {}}
          >
            Verificar sitio
          </button>
        </div>

      </div>
    </div>
  )
}